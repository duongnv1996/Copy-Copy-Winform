Copy Copy Winform Installation

1. Click 'setup.exe' to install application
2. Enter your code from mobile application to connect other devices
3. Copy any thing.

Enjoy!